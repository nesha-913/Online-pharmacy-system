<?php include_once("header.php"); ?>

<!DOCTYPE html>
<head> <h1> <center>Terms and Conditions</center></h1>


<style> body{
        background-color:lightblue;
     
    
    }</style>
    </head>
<p><h2>Privacy Policy </h2>

    Our privacy policy, which sets out how we will use your information, can be found at privacy and policy . By using this website, you consent to the processing described therein and warrant that all data provided by you is accurate.
    <h2>Our Contract</h2>
    When you place and order, you will receive an acknowlegment email confirming receipt of your order. A contract between us will be formed until when this email is sent only those goods listed in the confirmation email will be included in the contract formed.
    <h2>Payment</h2>
    Upcoming receiving your order we crry out a standard authorization check on your payment card to ensure there are suffient funds to fill the transaction. You card will be depited upon authorisation being received.
    </p>





</html>