<?php include_once("header.php"); ?>
<!DOCTYPE html>
<head><h1><font color:#045F5F><center>About Us</center></font></h1>
<style>
    body{
        background-color:lightblue;
     
    
    }
</style>

</head>
<br>
<hr>




    <body>
       <img src="xampp\htdocs\online\img\med1.jpg" alt="aboutus" aling="left" width ="300" height="350">
       <p ><font size="5"> "Central Pharmacy" is the best baranded online pharmacy plattform in Sri Lanka. The organization, headed by a team of professionals has introduced an innovative retail concept centered on exceptional shopper experience through service, technology,product offering, pricing and a hostof value additions. Through this concept has gained market leadership position in Drugg store Retailing with a loyal consumer base.
        <br>
        <br>
        Centered on this belief, our business model srives to be more just than an ordinary pharmacy in our offerings, format and solutions. Our view of healthcare retailing is not limited to the narrow focus of pharmaceuticals. To us healthcare retailing is also about living better and lokking better. 
       </p>
       
    </body>

</html>