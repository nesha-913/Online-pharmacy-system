<footer>
   
    <div class="contact1">
        <p>HOTLINE<br>
            +94 115796834<br>
            +94744586985<br>
            +94768753648<br></p>
    </div>
    <div class="address1">
    <p>Address:<br> NO 13/A.KADUWELA ROAD,<br>
             MALABE</p>
</div>
  
</footer>
</html>