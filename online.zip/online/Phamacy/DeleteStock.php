<style>
    body {
 background-color: #CEECF5;
}
</style>

<?php

if(isset($_GET["ID"])){
    $ID = $_GET["ID"];
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "online"; //change DB name

    //connection
    $connection = new mysqli($servername,$username,$password,$database);
    $sql = "DELETE FROM stock WHERE ID =$ID";
     $connection->query($sql);

    
    }
    header("location:StockList.php");
    exit;

?>