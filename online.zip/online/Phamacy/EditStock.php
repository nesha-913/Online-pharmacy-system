<?php include_once("header.php"); ?>

<?php
	 
     $ItemName= "";
     $Price= "";
     $Description= "";
     $QTY= "";



    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "online"; //change DB name

    //connection
    $connection = new mysqli($servername,$username,$password,$database);
   
    $errorMessage = "";
    $successMessage = "";


    if($_SERVER['REQUEST_METHOD']=='GET'){

        if(!isset($_GET["ID"])){
        header("location:/Phamacy/EnterStock.php");
        exit;
        }

        $ID= $_GET["ID"];


        $sql = "SELECT * FROM stock where ID=$ID";
        $result = $connection->query($sql);
        $row = $result->fetch_assoc();

        if(!$row){
            header("location:/Phamacy/EnterStock.php");
            exit;
        }

        $ID= $row["ID"];
        $ItemName= $row["ItemName"];
        $Price= $row["Price"];
        $Description= $row["Description"];
        $QTY= $row["QTY"];

    }
        else{
            $ID= $_POST["ID"];
            $ItemName= $_POST["ItemName"];
            $Price= $_POST["Price"];
            $Description= $_POST["Description"];        
            $QTY= $_POST["QTY"];
            

            do{
                if(empty($ID) || empty($ItemName) || empty($Price) || empty($Description)|| empty($QTY) )
                  {
                    $errorMessage = "Please Fill Emty Fields";
                  break;
                }
                
                  $sql = "UPDATE stock " .
                 " SET ItemName = '$ItemName',Price = '$Price',Description = '$Description', QTY = '$QTY' WHERE ID = $ID  ";
                 $result = $connection->query($sql);
                 if(!$result){
                     die("invalied Query  - ".$connection->error);
                     break;
                 }
            
                 $ID= "";
                 $ItemName= "";
                 $Price= "";
                 $Description= "";
                 $QTY= "";
            
                $successMessage = "Stock Update Successfully";
            
                }while(false);
            

        }

       

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script str="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
    body {

 background-image: url('img/pharmacy10.jpeg');
 background-size: cover; 
 background-repeat: no-repeat; 
 background-position: center; 

}
</style>
    
</head>
<body>
<div class="container my-5">
    <?php
    if(!empty($errorMessage)){
        echo "
        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
        <strong> $errorMessage </strong>
        </div>
        ";
    }

    ?>
<h2>Edit Stock</h2>
<form method="post">
    <input type="hidden"  name="ID" value="<?php echo $ID ; ?>">
    <div class="row mb-3">
        <label class="col-sm-3 col-form-lable">Item Name</label>
        <div class="col-sm-6">
        <input type="text" class="form-control" name="ItemName" value="<?php echo $ItemName  ?>">
        </div>
    </div>
    <div class="row mb-3">
        <label class="col-sm-3 col-form-lable">Price</label>
        <div class="col-sm-6">
        <input type="text" class="form-control" name="Price" value="<?php echo $Price  ?>">
        </div>
    </div>

    <div class="row mb-3">
        <label class="col-sm-3 col-form-lable">Description</label>
        <div class="col-sm-6">
        <input type="text" class="form-control" name="Description" value="<?php echo $Description  ?>">
        </div>
    </div>
    
    <div class="row mb-3">
        <label class="col-sm-3 col-form-lable">QTY</label>
        <div class="col-sm-6">
        <input type="text" class="form-control" name="QTY" value="<?php echo $QTY  ?>">
        </div>
    </div>

    <?php
    if(!empty($successMessage)){
        echo "
        <div class='alert alert-success alert-dismissible fade show' role='alert'>
        <strong> $successMessage </strong>
        </div>
        ";
    }
    ?>
    <div class="row mb-3">
        
        <div class="col-sm-3">
        <button type="submit" class='btn btn-primary'  >Submit</button>
        </div>
        <div class="col-sm-3">
        <a class='btn btn-danger btn-sm' href='http://localhost/phamacy/EnterStock.php' >Cancle</a>
        </div>
    </div>
</form>


</div>
</body>
</html>