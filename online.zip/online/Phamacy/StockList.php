<?php include_once("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Now</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="style.css">
   
    <style>
    body {

 background-image: url('img/pharmacy10.jpeg');
 background-size: cover; 
 background-repeat: no-repeat; 
 background-position: center; 

}
</style>
</head>
<body>
    <div class="container my-5">
        <h2>Stock list</h2>
        <a class="btn btn-primary" href="/phamacy/EnterStock.php" role="button">New Item</a>
<br>
    <table class="table">
        <thead>
            <th>ID</th>
            <th>Item Name</th>
            <th>Price</th>
            <th>Description</th>
            <th>QTY</th>
            <th></th>
        </thead>
        <tbody>
            <tr>
                <?php    
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "online"; //change DB name

                //connection
                $connection = new mysqli($servername,$username,$password,$database);

                if($connection->connect_error){
                    die("connection Failed".$connection->connect_error);
                }
                $sql = "SELECT * FROM stock";
                $result = $connection->query($sql);

                if(!$result){
                    die("invalied Query".$connection->error);
                }

                while($row = $result->fetch_assoc()){
                    echo "
                    </tr>
                    <td>$row[ID]</td>
                    <td>$row[ItemName]</td>
                    <td>$row[Price]</td>
                    <td>$row[Description]</td>
                    <td>$row[QTY]</td>
                    <td>
                    <a class='btn btn-primary btn-sm' href='EditStock.php?ID=$row[ID]'>Edit</a>
                    <a class='btn btn-danger btn-sm' href='DeleteStock.php?ID=$row[ID]'>Delete</a>
                    </td>
                    </tr>
                    ";
                }
                ?>
                
            
        </tbody>
    </table>
    </div>
    <?php include_once("footer.php"); ?>
</body>
</html>