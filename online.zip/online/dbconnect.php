<?php
$sr="localhost";
$un="root";
$pw="";
$db="online";

$con=mysqli_connect($sr,$un,$pw,$db);

/* print "Connect Successfully"; */

?>